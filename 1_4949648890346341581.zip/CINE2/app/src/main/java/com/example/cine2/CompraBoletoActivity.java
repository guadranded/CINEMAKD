package com.example.cine2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import android.view.View;
import android.widget.AdapterView;

public class CompraBoletoActivity extends AppCompatActivity {
    private TextView tituloTextView, horarioTextView, salaTextView, contadorTextView, totalTextView, precioEntradaTextView;
    private Spinner sucursalSpinner, fechaSpinner;
    private RadioGroup radioGroupFormato;
    private RadioButton radioButton2D, radioButton3D;
    private Button buttonIncrementar, buttonDecrementar, buttonCancelar, buttonContinuar;
    private int cantidad = 0;
    private double precioEntrada = 35.00;

    // HashMap para los horarios y salas según fecha y formato
    private HashMap<String, String> horarios2D = new HashMap<>();
    private HashMap<String, String> horarios3D = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.compra_boleto);

        // Referencias a los elementos de la interfaz
        tituloTextView = findViewById(R.id.titulo_pelicula);
        horarioTextView = findViewById(R.id.horario);
        salaTextView = findViewById(R.id.sala);
        contadorTextView = findViewById(R.id.contador_entradas);
        precioEntradaTextView = findViewById(R.id.precio_entrada);
        sucursalSpinner = findViewById(R.id.spinner_sucursal);
        fechaSpinner = findViewById(R.id.spinner_fechas);
        radioGroupFormato = findViewById(R.id.radioGroupFormato);
        radioButton2D = findViewById(R.id.radioButton_2d);
        radioButton3D = findViewById(R.id.radioButton_3d);
        buttonIncrementar = findViewById(R.id.button_incrementar);
        buttonDecrementar = findViewById(R.id.button_decrementar);
        buttonCancelar = findViewById(R.id.button_cancelar);
        buttonContinuar = findViewById(R.id.button_continuar);

        // Configuración de horarios
        configurarHorarios();

        // Evento de cambio de formato (2D/3D)
        radioGroupFormato.setOnCheckedChangeListener((group, checkedId) -> {
            actualizarPrecioYHorario();
        });

        // Evento de cambio de fecha
        fechaSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                actualizarPrecioYHorario();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Puede dejarse vacío si no necesitas manejar esta situación.
            }
        });

        // Botones de cantidad
        buttonIncrementar.setOnClickListener(v -> {
            cantidad++;
            actualizarTotal();
        });

        buttonDecrementar.setOnClickListener(v -> {
            if (cantidad > 0) {
                cantidad--;
                actualizarTotal();
            }
        });

        // Botón cancelar (volver a la pantalla de detalles de película)
        buttonCancelar.setOnClickListener(v -> {
            finish(); // Finaliza la actividad actual, volviendo a la anterior.
        });

        // Botón continuar (ir a la próxima pantalla)
        buttonContinuar.setOnClickListener(v -> {
            // Implementar la lógica para continuar a la siguiente pantalla
        });
    }

    // Método para configurar los horarios por fecha y formato
    private void configurarHorarios() {
        horarios2D.put("25/10/2024", "7:00 PM, Sala A");
        horarios2D.put("26/10/2024", "5:00 PM, Sala B");
        horarios2D.put("27/10/2024", "6:00 PM, Sala A");

        horarios3D.put("25/10/2024", "8:00 PM, Sala C");
        horarios3D.put("26/10/2024", "6:00 PM, Sala D");
        horarios3D.put("27/10/2024", "7:30 PM, Sala C");
    }

    // Método para actualizar el precio y el horario según la selección del usuario
    private void actualizarPrecioYHorario() {
        String fechaSeleccionada = (String) fechaSpinner.getSelectedItem();
        if (radioButton2D.isChecked()) {
            precioEntrada = 35.00;
            String horarioSala = horarios2D.get(fechaSeleccionada);
            if (horarioSala != null) {
                String[] partes = horarioSala.split(", ");
                horarioTextView.setText("HORARIO: " + partes[0]);
                salaTextView.setText("SALA: " + partes[1]);
            }
            precioEntradaTextView.setText("Digital 2D\nQ35.00");
        } else if (radioButton3D.isChecked()) {
            precioEntrada = 45.00;
            String horarioSala = horarios3D.get(fechaSeleccionada);
            if (horarioSala != null) {
                String[] partes = horarioSala.split(", ");
                horarioTextView.setText("HORARIO: " + partes[0]);
                salaTextView.setText("SALA: " + partes[1]);
            }
            precioEntradaTextView.setText("Digital 3D\nQ45.00");
        }
        actualizarTotal();
    }

    // Método para actualizar el total a pagar
    private void actualizarTotal() {
        double total = cantidad * precioEntrada;
        totalTextView.setText(String.format("TOTAL A PAGAR: Q%.2f", total));
        contadorTextView.setText(String.valueOf(cantidad));
    }
}
