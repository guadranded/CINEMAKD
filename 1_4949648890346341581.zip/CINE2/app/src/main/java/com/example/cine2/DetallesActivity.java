package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DetallesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.peliculas); // Asegúrate de que este es el layout correcto

        // Botón para ir a detallespeli.xml (Detalles de la película "Kraven")
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inicia la actividad de detalles de la película Kraven
                Intent intent = new Intent(DetallesActivity.this, DetallesPeliActivity.class);
                startActivity(intent);
            }
        });

        // Botón para ir a detallespeli2.xml (Detalles de la segunda película)
        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inicia la actividad de detalles de la segunda película
                Intent intent = new Intent(DetallesActivity.this, DetallesPeli2Activity.class);
                startActivity(intent);
            }
        });
    }
}
