package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class CompraExitosaActivity extends AppCompatActivity {
    private Button buttonInicio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.compra_exitosa);

        buttonInicio = findViewById(R.id.button_inicio);

        // Navegar a la pantalla de cartelera cuando el usuario hace clic en "INICIO"
        buttonInicio.setOnClickListener(v -> {
            Intent intent = new Intent(CompraExitosaActivity.this, CarteleraActivity.class);
            startActivity(intent);
            finish(); // Opcional, para cerrar la pantalla de "Compra Exitosa"
        });
    }
}
