package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DatosFacturacionActivity extends AppCompatActivity {
    private EditText numeroTarjetaEditText, mesExpiracionEditText, anoExpiracionEditText, cvvEditText;
    private Button buttonConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datos_facturacion);

        numeroTarjetaEditText = findViewById(R.id.numero_tarjeta);
        mesExpiracionEditText = findViewById(R.id.mes_expiracion);
        anoExpiracionEditText = findViewById(R.id.ano_expiracion);
        cvvEditText = findViewById(R.id.cvv);
        buttonConfirmar = findViewById(R.id.button_confirmar);

        buttonConfirmar.setOnClickListener(v -> {
            if (validarDatosPago()) {
                // Redirigir a la pantalla de "Compra Exitosa"
                Intent intent = new Intent(DatosFacturacionActivity.this, CompraExitosaActivity.class);
                startActivity(intent);
            } else {
                // Redirigir a la pantalla de "Error en los datos"
                Intent intent = new Intent(DatosFacturacionActivity.this, ErrorDatosActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean validarDatosPago() {
        String numeroTarjeta = numeroTarjetaEditText.getText().toString().trim();
        String mesExpiracion = mesExpiracionEditText.getText().toString().trim();
        String anoExpiracion = anoExpiracionEditText.getText().toString().trim();
        String cvv = cvvEditText.getText().toString().trim();

        if (numeroTarjeta.isEmpty() || numeroTarjeta.length() != 16) {
            return false;
        }
        if (mesExpiracion.isEmpty() || Integer.parseInt(mesExpiracion) < 1 || Integer.parseInt(mesExpiracion) > 12) {
            return false;
        }
        if (anoExpiracion.isEmpty() || Integer.parseInt(anoExpiracion) < 24) {
            return false;
        }
        if (cvv.isEmpty() || cvv.length() != 3) {
            return false;
        }

        return true;
    }
}
