package com.example.cine2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class RegisterActivity extends AppCompatActivity {

    private EditText nameInput, phoneInput, emailInput, passwordInput, departmentInput, municipalityInput;
    private Button registerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar vistas
        nameInput = findViewById(R.id.name_input);
        phoneInput = findViewById(R.id.numero_input);
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input_register);
        departmentInput = findViewById(R.id.departamento_input);
        municipalityInput = findViewById(R.id.municipio_input);
        registerBtn = findViewById(R.id.register_btn);

        // Configurar el botón de registro
        registerBtn.setOnClickListener(v -> {
            String nombre = nameInput.getText().toString();
            String telefono = phoneInput.getText().toString();
            String correo = emailInput.getText().toString();
            String contrasena = passwordInput.getText().toString();
            String departamento = departmentInput.getText().toString();
            String municipio = municipalityInput.getText().toString();

            // Llamar al método para registrar el usuario
            new RegisterTask().execute(nombre, telefono, correo, contrasena, departamento, municipio);
        });
    }

    // AsyncTask para manejar la solicitud de registro en segundo plano
    private class RegisterTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String nombre = params[0];
            String telefono = params[1];
            String correo = params[2];
            String contrasena = params[3];
            String departamento = params[4];
            String municipio = params[5];

            try {
                // URL de tu archivo PHP en el servidor local
                URL url = new URL("http://192.168.1.238/register.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                // Datos que serán enviados en la solicitud POST
                String postData = "NOMBRE=" + nombre + "&TELEFONO=" + telefono + "&CORREO=" + correo +
                        "&CONTRASEÑA=" + contrasena + "&DEPARTAMENTO=" + departamento + "&MUNICIPIO=" + municipio;

                // Enviar los datos al servidor
                OutputStream os = conn.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();

                // Leer la respuesta del servidor
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                return response.toString(); // Retorna la respuesta del servidor

            } catch (Exception e) {
                e.printStackTrace();
                return "error";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            // Manejar la respuesta del servidor
            if (result.equals("success")) {
                Toast.makeText(RegisterActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                // Redirigir de nuevo al login
                finish(); // Finaliza esta actividad y vuelve al MainActivity
            } else {
                Toast.makeText(RegisterActivity.this, "Error en el registro", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
