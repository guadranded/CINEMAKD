package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginBtn;
    private Button createAccountBtn; // Botón de crear cuenta

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar vistas
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        loginBtn = findViewById(R.id.login_btn);
        createAccountBtn = findViewById(R.id.create_acount_btn); // Botón para registrar nuevo usuario

        // Configurar click listener para el botón de inicio de sesión
        loginBtn.setOnClickListener(v -> {
            // Mostrar mensaje temporal
            Toast.makeText(MainActivity.this, "Redirigiendo a Cartelera", Toast.LENGTH_SHORT).show();
            // Redirigir a la CarteleraActivity
            Intent intent = new Intent(MainActivity.this, CarteleraActivity.class);
            startActivity(intent);
        });

        // Configurar click listener para el botón de crear cuenta
        createAccountBtn.setOnClickListener(v -> {
            // Abrir la pantalla de registro
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent); // Iniciar la actividad de registro
        });
    }
}
