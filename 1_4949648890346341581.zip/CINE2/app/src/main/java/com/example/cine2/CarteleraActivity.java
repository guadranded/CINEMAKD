package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CarteleraActivity extends AppCompatActivity {

    private EditText editTextSearch;
    private ImageView iconSearch;
    private TextView titleMovies, kravenTitle, badBoysTitle, ozTitle;
    private ImageView kravenImage, badBoysImage, ozImage;
    private Button buttonDetailsKraven, buttonDetailsBadBoys, buttonDetailsMagoOz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.peliculas);

        // Inicializar vistas
        editTextSearch = findViewById(R.id.editText_search);
        iconSearch = findViewById(R.id.icon_search);
        titleMovies = findViewById(R.id.title_movies);
        kravenTitle = findViewById(R.id.textView);
        badBoysTitle = findViewById(R.id.textView2);
        ozTitle = findViewById(R.id.textView3);
        kravenImage = findViewById(R.id.imageView2);
        badBoysImage = findViewById(R.id.imageView8);
        ozImage = findViewById(R.id.imageView7);
        buttonDetailsKraven = findViewById(R.id.button);
        buttonDetailsBadBoys = findViewById(R.id.button2);
        buttonDetailsMagoOz = findViewById(R.id.button3);

        buttonDetailsKraven.setOnClickListener(v -> {
            Intent intent = new Intent(CarteleraActivity.this, DetallesActivity.class);
            startActivity(intent); // Iniciar la actividad de detalles
        });

        buttonDetailsBadBoys.setOnClickListener(v -> {
            // ABRIR DETALLES
            Intent intent = new Intent(CarteleraActivity.this, DetallesActivity.class);
            startActivity(intent); // Iniciar la actividad de detalles
        });
        buttonDetailsMagoOz.setOnClickListener(v -> {
            // ABRIR DETALLES
            Intent intent = new Intent(CarteleraActivity.this, DetallesActivity.class);
            startActivity(intent); // Iniciar la actividad de detalles
        });

    }
}
