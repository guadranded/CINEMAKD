
package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DetallesPeliActivity extends AppCompatActivity {
    private Button buttonComprarBoleto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detallespeli);

        // Botón "COMPRAR BOLETO" en la pantalla de detalles
        Button buttonComprarBoleto = findViewById(R.id.button_comprar_boleto);
        buttonComprarBoleto.setOnClickListener(v -> {
            Intent intent = new Intent(DetallesPeliActivity.this, CompraBoletoActivity.class);
            startActivity(intent); // Iniciar la actividad de detalles
        });
    }
}
